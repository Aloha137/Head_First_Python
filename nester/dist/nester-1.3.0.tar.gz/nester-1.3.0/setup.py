from distutils.core import setup 

setup(
      name = 'nester',
      version = '1.3.0',
      py_modules= ['nester'],
      author= 'vanlianhup',
      author_email= 'vanlianhup@gmail.com',
      url= 'http://www.vanlianhup.wordpress.com',
      description= 'This is texting for -- A simple printer of nested lists',
        
     )